// Select form using getElementById
const form = document.getElementById("studentForm");

// Select fields using getElementById
const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const program = document.getElementById("program");
const semester = document.getElementById("semester");

// Select preview elements using querySelector
const previewName = document.querySelector("#previewName");
const previewEmail = document.querySelector("#previewEmail");
const previewProgram = document.querySelector("#previewProgram");
const previewSemester = document.querySelector("#previewSemester");

const previewCard = document.querySelector("#previewCard");
const darkModeBtn = document.querySelector("#darkModeBtn");

const studentList = document.querySelector("#studentList");


// Live preview using input event
fullName.addEventListener("input", function () {
    previewName.textContent = fullName.value || "Student Name";
});

email.addEventListener("input", function () {
    previewEmail.textContent = "Email: " + email.value;
});

program.addEventListener("input", function () {
    previewProgram.textContent = "Program: " + program.value;
});

semester.addEventListener("input", function () {
    previewSemester.textContent = "Semester: " + semester.value;
});


// Form submit
form.addEventListener("submit", function (event) {

    // Stop page from refreshing
    event.preventDefault();

    // Get error elements
    const nameError = document.querySelector("#nameError");
    const emailError = document.querySelector("#emailError");
    const programError = document.querySelector("#programError");
    const semesterError = document.querySelector("#semesterError");

    // Clear old errors
    nameError.textContent = "";
    emailError.textContent = "";
    programError.textContent = "";
    semesterError.textContent = "";

    let valid = true;

    // Validate name
    if (fullName.value.trim() === "") {
        nameError.textContent = "Please enter your full name.";
        valid = false;
    }

    // Validate email
    if (email.value.trim() === "") {
        emailError.textContent = "Please enter your email.";
        valid = false;
    }

    // Validate program
    if (program.value === "") {
        programError.textContent = "Please select a program.";
        valid = false;
    }

    // Validate semester
    if (semester.value === "") {
        semesterError.textContent = "Please enter your semester.";
        valid = false;
    }

    // If all fields are valid
    if (valid) {

        // Create a new list item
        const li = document.createElement("li");

        li.textContent =
            fullName.value + " | " +
            email.value + " | " +
            program.value + " | Semester " +
            semester.value;

        // Add student to the list
        studentList.appendChild(li);

        // Clear form
        form.reset();

        // Reset preview
        previewName.textContent = "Student Name";
        previewEmail.textContent = "Email: ";
        previewProgram.textContent = "Program: ";
        previewSemester.textContent = "Semester: ";
    }
});


// Dark mode button
darkModeBtn.addEventListener("click", function () {

    previewCard.classList.toggle("dark");

});